﻿using AutoMapper;
using EventSurvey.Entities;
using EventSurvey.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EventSurvey.Mapper
{
    public class EntityToViewModel : Profile
    {
        public EntityToViewModel()
        {
            CreateMap<User, UserViewModel>()
                 .ForMember(d => d.RoleName, v => v.MapFrom(s => s.Role.Role1));
            CreateMap<Survey, SurveyViewModel>()
                .ForMember(d => d.Id, v => v.MapFrom(s => s.Id))
                .ForMember(d => d.SurveyName, v => v.MapFrom(s => s.Name))
                .ForMember(d => d.SurveyDescription, v => v.MapFrom(s => s.Description))
                .ForMember(d => d.questionViewModels, v => v.MapFrom(s => AutoMapper.Mapper.Map<ICollection<Question>, ICollection<QuestionViewModel>>(s.Questions.Where(st => !st.IsDeleted).ToList())));
                 
            CreateMap<Question, QuestionViewModel>()
                .ForMember(d => d.QuestionDescription, v => v.MapFrom(s => s.QuestionDescription))
                .ForMember(d => d.choiceViewModels, v => v.MapFrom(s => AutoMapper.Mapper.Map<ICollection<Choice>, ICollection<ChoiceViewModel>>(s.Choices.Where(st => !st.IsDeleted).ToList())))
                .ForMember(d => d.answerViewModels, v => v.MapFrom(s => AutoMapper.Mapper.Map<ICollection<Answer>, ICollection<AnswerViewModel>>(s.Answers.Where(st => !st.IsDeleted).ToList()))); 
            CreateMap<Choice, ChoiceViewModel>()
             .ForMember(d => d.ChoiceDescription, v => v.MapFrom(s => s.ChoiceDescription));
            CreateMap<QuestionType, QuestionTypeViewModel>()
             .ForMember(d => d.QuestionType, v => v.MapFrom(s => s.Type));
            CreateMap<Answer, AnswerViewModel>();
        }
    }
}