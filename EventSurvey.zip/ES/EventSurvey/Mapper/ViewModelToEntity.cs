﻿using AutoMapper;
using EventSurvey.Entities;
using EventSurvey.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EventSurvey.Mapper
{
    public class ViewModelToEntity : Profile
    {
        public ViewModelToEntity()
        {
            CreateMap<SurveyViewModel,Survey>()
                 .ForMember(d => d.Name, v => v.MapFrom(s => s.SurveyName))
                 .ForMember(d => d.Description, v => v.MapFrom(s => s.SurveyDescription))
                 .ForMember(d => d.IsDeleted, v => v.MapFrom(s => s.IsDeleted));
            CreateMap<QuestionViewModel, Question>()
                .ForMember(d => d.SurveyId, v => v.MapFrom(s => s.SurveyId))
                .ForMember(d => d.QuestionTypeId, v => v.MapFrom(s => s.QuestionTypeId))
                .ForMember(d => d.QuestionDescription, v => v.MapFrom(s => s.QuestionDescription))
                .ForMember(d => d.Choices, v => v.MapFrom(s => AutoMapper.Mapper.Map<ICollection<ChoiceViewModel>, ICollection<Choice>>(s.choiceViewModels.Where(st => !st.IsDeleted).ToList())));
            CreateMap<ChoiceViewModel, Choice>()
                .ForMember(d => d.ChoiceDescription, v => v.MapFrom(s => s.ChoiceDescription));
            CreateMap<AnswerViewModel, Answer>()
                .ForMember(d=>d.SurveyId,v=>v.MapFrom(s=>s.SurveyId))
                .ForMember(d => d.QuestionId, v => v.MapFrom(s => s.QuestionId))
                .ForMember(d => d.ChoiceId, v => v.MapFrom(s => s.ChoiceId))
                .ForMember(d => d.AnswerDescription, v => v.MapFrom(s => s.AnswerDescription))
                .ForMember(d => d.AnsweredById, v => v.MapFrom(s => s.AnsweredById));
        }
    }
}