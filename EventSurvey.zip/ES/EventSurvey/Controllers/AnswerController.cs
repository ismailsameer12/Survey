﻿using EventSurvey.Models;
using EventSurvey.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;

namespace EventSurvey.Controllers
{
    public class AnswerController : Controller
    {
        // GET: Answer
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public JsonResult AddResponse(List<AnswerViewModel> answerViewModel)
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            try
            {
                using (var transactionScope = new TransactionScope())
                {
                    if (answerViewModel != null)
                    {
                        using (RepositoryDataAccessLayer<Entities.Answer> AnswerEntity = new Repositories.RepositoryDataAccessLayer<Entities.Answer>())
                        {
                            var answers = AutoMapper.Mapper.Map<List<AnswerViewModel>, List<Entities.Answer>>(answerViewModel);
                            if (answers != null)
                            {
                                var answer = answers.FirstOrDefault();
                                var Answers = AnswerEntity.Find(s=> !s.IsDeleted && s.SurveyId == answer.SurveyId && s.AnsweredById == answer.AnsweredById);
                                if (Answers == null)
                                {
                                    foreach (var _answer in answers)
                                    {
                                        AnswerEntity.Add(_answer);
                                    }
                                    transactionScope.Complete();
                                    responseViewModel.IsSuccess = true;
                                    responseViewModel.Message = "Your response has been added successfully";
                                }
                                else
                                {
                                    transactionScope.Dispose();
                                    responseViewModel.IsSuccess = false;
                                    responseViewModel.Message = "Already answered for this survey";
                                }
                            }
                        }
                    }
                    else
                    {
                        transactionScope.Dispose();
                        responseViewModel.IsSuccess = false;
                        responseViewModel.Message = "Failed";
                    }
                }
            }
            catch (Exception ex)
            {
                responseViewModel.IsSuccess = false;
                responseViewModel.Message = ex.Message;
            }
            return Json(responseViewModel);
        }
    }
}