﻿using EventSurvey.Common;
using EventSurvey.Entities;
using EventSurvey.Models;
using EventSurvey.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;

namespace EventSurvey.Controllers
{
    public class SurveyController : Controller
    {
        public RepositoryDataAccessLayer<Survey> _surveyEntity;
        public RepositoryDataAccessLayer<Survey> SurveyEntity
        {
            get
            {
                return _surveyEntity;
            }
            set
            {
                _surveyEntity = value;
            }
        }
        // GET: Survey
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public JsonResult GetAllSurvey()
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            try
            {
                using (RepositoryDataAccessLayer<Entities.Survey> SurveyEntity = new Repositories.RepositoryDataAccessLayer<Entities.Survey>())
                {
                    List<SurveyViewModel> surveyViewModels = new List<SurveyViewModel>();
                    List<Survey> surveys = SurveyEntity.FindBy(s => !s.IsDeleted).ToList();
                    if (surveys.Any())
                    {
                        foreach (var _survey in surveys)
                        {
                            var surveyVM = AutoMapper.Mapper.Map<Survey, SurveyViewModel>(_survey);
                            if (!surveyVM.IsMailSent.HasValue || !surveyVM.IsMailSent.Value)
                            {
                                if (!surveyVM.questionViewModels.Any())
                                    surveyVM.IsMailSent = true;
                            }
                            surveyViewModels.Add(surveyVM);
                        }
                        surveyViewModels = surveyViewModels.OrderByDescending(s => s.Id).ToList();

                        responseViewModel.IsSuccess = true;
                        responseViewModel.Message = "Success";
                        responseViewModel.Object = surveyViewModels;
                    }
                }
            }
            catch (Exception ex)
            {
                responseViewModel.IsSuccess = false;
                responseViewModel.Message = "Failed";
            }
            return Json(responseViewModel);
        }

        [HttpPost]
        public JsonResult CreateNewSurvey(SurveyViewModel surveyViewModel)
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            try
            {
                using (var transactionScope = new TransactionScope())
                {
                    if (surveyViewModel != null)
                    {
                        using (RepositoryDataAccessLayer<Entities.Survey> SurveyEntity = new Repositories.RepositoryDataAccessLayer<Entities.Survey>())
                        {
                            var survey = AutoMapper.Mapper.Map<SurveyViewModel, Survey>(surveyViewModel);
                            if (survey != null)
                            {
                                SurveyEntity.Add(survey);
                                transactionScope.Complete();
                                responseViewModel.IsSuccess = true;
                                responseViewModel.Message = "Success";
                            }
                        }
                    }
                    else
                    {
                        transactionScope.Dispose();
                        responseViewModel.IsSuccess = false;
                        responseViewModel.Message = "Failed";
                    }
                }
            }
            catch (Exception ex)
            {
                responseViewModel.IsSuccess = false;
                responseViewModel.Message = ex.Message;
            }
            return Json(responseViewModel);
        }

        [HttpPost]
        public JsonResult EditSurvey(SurveyViewModel surveyViewModel)
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            try
            {
                using (var transactionScope = new TransactionScope())
                {
                    if (surveyViewModel != null)
                    {
                        using (RepositoryDataAccessLayer<Entities.Survey> SurveyEntity = new Repositories.RepositoryDataAccessLayer<Entities.Survey>())
                        {
                            var survey = AutoMapper.Mapper.Map<SurveyViewModel, Survey>(surveyViewModel);
                            if (survey != null)
                            {
                                var _survey = SurveyEntity.Find(s => s.Id == survey.Id && !s.IsDeleted);
                                if (_survey != null)
                                {
                                    SurveyEntity.Update(survey);
                                    transactionScope.Complete();
                                    responseViewModel.IsSuccess = true;
                                    responseViewModel.Message = "Success";
                                }
                                else
                                {
                                    transactionScope.Dispose();
                                    responseViewModel.IsSuccess = false;
                                    responseViewModel.Message = "Failed";
                                }
                            }
                        }
                    }
                    else
                    {
                        transactionScope.Dispose();
                        responseViewModel.IsSuccess = false;
                        responseViewModel.Message = "Failed";
                    }
                }
            }
            catch (Exception ex)
            {
                responseViewModel.IsSuccess = false;
                responseViewModel.Message = ex.Message;
            }
            return Json(responseViewModel);
        }

        [HttpPost]
        public JsonResult DeleteSurvey(int surveyId)
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            try
            {
                using (var transactionScope = new TransactionScope())
                {
                    if (surveyId > 0)
                    {
                        using (RepositoryDataAccessLayer<Entities.Survey> SurveyEntity = new Repositories.RepositoryDataAccessLayer<Entities.Survey>())
                        {
                            var _survey = SurveyEntity.Find(s => s.Id == surveyId && !s.IsDeleted);
                            if (_survey != null)
                            {
                                SurveyEntity.Delete(_survey);
                                transactionScope.Complete();
                                responseViewModel.IsSuccess = true;
                                responseViewModel.Message = "Success";
                            }
                            else
                            {
                                transactionScope.Dispose();
                                responseViewModel.IsSuccess = false;
                                responseViewModel.Message = "Failed";
                            }
                        }
                    }
                    else
                    {
                        transactionScope.Dispose();
                        responseViewModel.IsSuccess = false;
                        responseViewModel.Message = "Failed";
                    }
                }
            }
            catch (Exception ex)
            {
                responseViewModel.IsSuccess = false;
                responseViewModel.Message = ex.Message;
            }
            return Json(responseViewModel);
        }
        [HttpPost]
        public JsonResult GetById(string id)
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            try
            {
                Encryption encryption = new Encryption();
                int surveyId = Convert.ToInt32(encryption.Decrypt(id.ToString()));
                using (RepositoryDataAccessLayer<Entities.Survey> SurveyEntity = new Repositories.RepositoryDataAccessLayer<Entities.Survey>())
                {
                    Survey surveys = SurveyEntity.FindBy(s => s.Id == surveyId && !s.IsDeleted).FirstOrDefault();
                    var surveyVM = AutoMapper.Mapper.Map<Survey, SurveyViewModel>(surveys);
                    responseViewModel.IsSuccess = true;
                    responseViewModel.Message = "Success";
                    responseViewModel.Object = surveyVM;
                }
            }
            catch (Exception ex)
            {
                responseViewModel.IsSuccess = false;
                responseViewModel.Message = "Failed";
            }
            return Json(responseViewModel);
        }
    }
}