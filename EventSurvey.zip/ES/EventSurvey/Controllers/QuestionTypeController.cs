﻿using EventSurvey.Entities;
using EventSurvey.Models;
using EventSurvey.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;

namespace EventSurvey.Controllers
{
    public class QuestionTypeController : Controller
    {
        // GET: QuestionType
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public JsonResult Get()
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            using (TransactionScope transaction = new TransactionScope())
            {
                try
                {
                    using (RepositoryDataAccessLayer<QuestionType> questionTypeEntity = new Repositories.RepositoryDataAccessLayer<QuestionType>())
                    {
                        List<QuestionType> questionType = questionTypeEntity.Filter(s => !s.IsDeleted).ToList();
                        List<QuestionTypeViewModel> questionViewModel = AutoMapper.Mapper.Map<ICollection<QuestionType>, ICollection<QuestionTypeViewModel>>(questionType).ToList();
                        responseViewModel.IsSuccess = true;
                        responseViewModel.Message = "Success";
                        responseViewModel.Object = questionViewModel;
                        transaction.Complete();
                    }
                }
                catch (Exception ex)
                {
                    transaction.Dispose();
                    responseViewModel.IsSuccess = false;
                    responseViewModel.Message = ex.Message;
                }
            }
            return Json(responseViewModel,JsonRequestBehavior.AllowGet);
        }
    }
}