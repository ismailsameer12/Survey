﻿using EventSurvey.Entities;
using EventSurvey.Models;
using EventSurvey.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;

namespace EventSurvey.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult userResponse(string surveyId)
        {            
            if (surveyId == "")
                return View();
            else
                return Redirect("~/account/login?returnUrl=user/userResponse?surveyId="+ surveyId);
        }

        [HttpPost]
        public JsonResult Login(string userName, string password)
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            try
            {
                using (RepositoryDataAccessLayer<User> UserEntity = new Repositories.RepositoryDataAccessLayer<Entities.User>())
                {
                    User user = UserEntity.Find(s => s.Email == userName || s.Username == userName);
                    if (user != null)
                    {
                        if (user.Password.Equals(password))
                        {
                            responseViewModel.IsSuccess = true;
                            responseViewModel.Message = "Success";
                            UserViewModel userViewMode = AutoMapper.Mapper.Map<User, UserViewModel>(user);
                            responseViewModel.Object = userViewMode;
                        }
                        else
                        {
                            responseViewModel.IsSuccess = false;
                            responseViewModel.Message = "Failed";
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                responseViewModel.IsSuccess = false;
                responseViewModel.Message = ex.Message;
            }
            return Json(responseViewModel);
        }
        [HttpPost]
        [AllowAnonymous]
        public JsonResult SignUp(UserViewModel userViewModel)
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    using (RepositoryDataAccessLayer<User> UserEntity = new Repositories.RepositoryDataAccessLayer<Entities.User>())
                    {
                        if (userViewModel != null)
                        {
                            if (!string.IsNullOrEmpty(userViewModel.ConfirmPassword) && !string.IsNullOrEmpty(userViewModel.Password) && userViewModel.Password.Equals(userViewModel.ConfirmPassword))
                            {
                                List<User> users = UserEntity.Filter(s => !s.IsDeleted).ToList();
                                if (users.Any(s => s.Username.ToLower() == userViewModel.Username.ToLower() || s.Email.ToLower() == userViewModel.Email.ToLower()))
                                {
                                    transactionScope.Dispose();
                                    responseViewModel.IsSuccess = false;
                                    responseViewModel.Message = "Username or Email is already exist.";
                                }
                                else
                                {
                                    User user = new Entities.User();
                                    user.Email = userViewModel.Email;
                                    user.Username = userViewModel.Username;
                                    user.RoleId = (int)Common.Role.User;
                                    user.Password = userViewModel.Password;
                                    user.IsDeleted = false;
                                    UserEntity.Add(user);
                                    transactionScope.Complete();
                                    responseViewModel.IsSuccess = true;
                                    responseViewModel.Message = "User has been added successfully.";
                                }
                            }
                            else
                            {
                                transactionScope.Dispose();
                                responseViewModel.IsSuccess = false;
                                responseViewModel.Message = "Password does not match.";
                            }
                        }
                        else
                        {
                            transactionScope.Dispose();
                            responseViewModel.IsSuccess = false;
                            responseViewModel.Message = "Parameter is empty.";
                        }
                    }
                }
                catch (Exception ex)
                {
                    transactionScope.Dispose();
                    responseViewModel.IsSuccess = false;
                    responseViewModel.Message = ex.Message;
                }
            }
            return Json(responseViewModel);
        }

        public ActionResult ForgotPassword()
        {
            //TODO
            return Json("Success");
        }

    }
}