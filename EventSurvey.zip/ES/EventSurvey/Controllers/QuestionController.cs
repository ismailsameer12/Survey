﻿using EventSurvey.Entities;
using EventSurvey.Helper;
using EventSurvey.Models;
using EventSurvey.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;

namespace EventSurvey.Controllers
{
    public class QuestionController : Controller
    {
        // GET: Question
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public JsonResult GetQuestionsBySurveyId(int surveyId)
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            try
            {
                using (RepositoryDataAccessLayer<Entities.Question> QuestionEntity = new Repositories.RepositoryDataAccessLayer<Entities.Question>())
                {
                    List<Entities.Question> questions = QuestionEntity.FindBy(s => s.SurveyId == surveyId && !s.IsDeleted).ToList();
                    if (questions.Any())
                    {
                        var questionVM = AutoMapper.Mapper.Map<List<Entities.Question>,List<QuestionViewModel>>(questions);
                        responseViewModel.IsSuccess = true;
                        responseViewModel.Message = "Success";
                        responseViewModel.Object = questionVM;
                    }
                    else
                    {
                        responseViewModel.IsSuccess = false;
                        responseViewModel.Message = "There is no questions for this survey";
                    }
                }
            }
            catch (Exception ex)
            {
                responseViewModel.IsSuccess = false;
                responseViewModel.Message = ex.Message;
            }
            return Json(responseViewModel);
        }
        [HttpPost]
        public JsonResult CreateQuestion(List<QuestionViewModel> questionViewModels)
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            try
            {
                using (var transactionScope = new TransactionScope())
                {
                    if (questionViewModels != null)
                    {
                        using (RepositoryDataAccessLayer<Entities.Question> QuestionEntity = new Repositories.RepositoryDataAccessLayer<Entities.Question>())
                        {
                            var questions = AutoMapper.Mapper.Map<List<QuestionViewModel>, List<Entities.Question>>(questionViewModels);
                            if (questions.Any())
                            {
                                foreach (var question in questions)
                                {
                                    QuestionEntity.Add(question);
                                }
                                transactionScope.Complete();
                                responseViewModel.IsSuccess = true;
                                responseViewModel.Message = "Questions has been added successfully";
                            }
                        }
                    }
                    else
                    {
                        transactionScope.Dispose();
                        responseViewModel.IsSuccess = false;
                        responseViewModel.Message = "Failed";
                    }
                }
            }
            catch (Exception ex)
            {
                responseViewModel.IsSuccess = false;
                responseViewModel.Message = ex.Message;
            }
            return Json(responseViewModel);
        }

        [HttpPost]
        public JsonResult EditQuestion(List<QuestionViewModel> questionViewModels)
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            try
            {
                using (var transactionScope = new TransactionScope())
                {
                    if (questionViewModels != null)
                    {
                        using (RepositoryDataAccessLayer<Entities.Question> QuestionEntity = new Repositories.RepositoryDataAccessLayer<Entities.Question>())
                        {
                            var questions = AutoMapper.Mapper.Map<List<QuestionViewModel>, List<Entities.Question>>(questionViewModels);
                            if (questions.Any())
                            {
                                var question = questions.Where(s => s.Id > 0).ToList();
                                foreach (var oldQuetion in question)
                                {
                                    QuestionEntity.Update(oldQuetion);
                                }
                                var newQuestion = questions.Where(s => s.Id == 0).ToList();
                                foreach (var _newques in newQuestion)
                                {
                                    QuestionEntity.Add(_newques);
                                }
                                transactionScope.Complete();
                                responseViewModel.IsSuccess = true;
                                responseViewModel.Message = "Success";
                            }
                        }
                    }
                    else
                    {
                        transactionScope.Dispose();
                        responseViewModel.IsSuccess = false;
                        responseViewModel.Message = "Failed";
                    }
                }
            }
            catch (Exception ex)
            {
                responseViewModel.IsSuccess = false;
                responseViewModel.Message = ex.Message;
            }
            return Json(responseViewModel);
        }

        [HttpPost]
        public JsonResult SendSurvey(int surveyId)
        {
            ResponseViewModel responseViewModel = new Models.ResponseViewModel();
            try
            {
                using (var transactionScope = new TransactionScope())
                {
                    using (RepositoryDataAccessLayer<Entities.User> userEntity = new Repositories.RepositoryDataAccessLayer<Entities.User>())
                    {
                        using (RepositoryDataAccessLayer<Entities.Survey> surveyEntity = new Repositories.RepositoryDataAccessLayer<Entities.Survey>())
                        {
                            List<User> users = userEntity.Filter(s => s.RoleId == (int)Common.Role.User && !s.IsDeleted).ToList();
                            Survey survey = surveyEntity.Find(s => s.Id == surveyId && (!s.IsMailSent.HasValue || s.IsMailSent.Value == false));
                            if (survey != null)
                            {
                                if (users.Any())
                                {
                                    List<string> mailId = users.Select(s => s.Email).ToList();
                                    Mail mail = new Helper.Mail();
                                    string mailContent = mail.GenerateURL(surveyId, survey.Name);
                                    mail.SetValues(mailId, survey.Name + " Survey", mailContent);
                                    mail.SendMail();

                                    survey.IsMailSent = true;
                                    surveyEntity.Update(survey);
                                    transactionScope.Complete();

                                    responseViewModel.IsSuccess = true;
                                    responseViewModel.Message = "Mail has been sent successfully";
                                }
                            }
                            else
                            {
                                responseViewModel.IsSuccess = false;
                                responseViewModel.Message = "Already mail has been sent";
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                responseViewModel.IsSuccess = false;
                responseViewModel.Message = ex.Message;
            }
            return Json(responseViewModel);
        }
    }
}