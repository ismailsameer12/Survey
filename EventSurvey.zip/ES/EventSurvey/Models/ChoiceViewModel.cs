﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EventSurvey.Models
{
    public class ChoiceViewModel
    {
        public int Id { get; set; }
        public int QuestionId { get; set; }
        public string ChoiceDescription { get; set; }
        public bool IsDeleted { get; set; }
    }
}