﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EventSurvey.Models
{
    public class AnswerViewModel
    {
        public int id { get; set; }
        public int SurveyId { get; set; }
        public int QuestionId { get; set; }
        public int? ChoiceId { get; set; }
        public string AnswerDescription { get; set; }
        public int AnsweredById { get; set; }
        public bool IsDeleted { get; set; }
    }
}