﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EventSurvey.Models
{
    public class SurveyViewModel
    {
        public SurveyViewModel()
        {
            questionViewModels = new List<QuestionViewModel>();
        }
        public int Id { get; set; }
        public string SurveyName { get; set; }
        public string SurveyDescription { get; set; }
        public bool IsDeleted { get; set; }
        public bool? IsMailSent { get; set; }
        public List<QuestionViewModel> questionViewModels { get; set; }
    }
}