﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EventSurvey.Models
{
    public class QuestionViewModel
    {
        public QuestionViewModel()
        {
            choiceViewModels = new List<ChoiceViewModel>();
            answerViewModels = new List<AnswerViewModel>();
        }
        public int Id { get; set; }
        public int SurveyId { get; set; }
        public int QuestionTypeId { get; set; }
        public string QuestionDescription { get; set; }
        public bool IsDeleted { get; set; }
        public List<AnswerViewModel> answerViewModels { get; set; }
        public List<ChoiceViewModel> choiceViewModels { get; set; }
    }
}