﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EventSurvey.Models
{
    public class ResponseViewModel
    {
        public bool IsSuccess { get; set; }

        public object Object { get; set; }

        public string Message { get; set; }

    }
}