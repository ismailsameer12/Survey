﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace EventSurvey.Common
{
    public class Encryption
    {
        private byte[] key = { };
        private const string EncryptionKey = "13$0f+$ivi$";
        private readonly byte[] IV = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };
        public string Encrypt(string Input)
        {
            try
            {
                key = Encoding.UTF8.GetBytes(EncryptionKey.Substring(0, 8));
                var des = new DESCryptoServiceProvider();
                Byte[] inputByteArray = Encoding.UTF8.GetBytes(Input);
                var ms = new MemoryStream();
                var cs = new CryptoStream(ms, des.CreateEncryptor(key, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                string encrypt = HttpUtility.UrlEncode(Convert.ToBase64String(ms.ToArray()).Replace("/", "-"));
                return encrypt.Replace(":", "&");
            }
            catch (Exception)
            {
                return "";
            }
        }
        public string Decrypt(string Input)
        {
            byte[] inputByteArray;

            try
            {
                key = Encoding.UTF8.GetBytes(EncryptionKey.Substring(0, 8));
                var des = new DESCryptoServiceProvider();
                Input = Input.Replace("&", ":");
                inputByteArray = Convert.FromBase64String((HttpUtility.UrlDecode(Input)).Replace(" ", "+").Replace("-", "/"));
                var ms = new MemoryStream();
                var cs = new CryptoStream(ms, des.CreateDecryptor(key, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                Encoding encoding = Encoding.UTF8;
                return encoding.GetString(ms.ToArray());
            }
            catch (Exception ex)
            {
                return "";
            }
        }
    }
}