﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(EventSurvey.Startup))]
namespace EventSurvey
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
