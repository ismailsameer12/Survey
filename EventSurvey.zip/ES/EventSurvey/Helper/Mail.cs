﻿using EventSurvey.Common;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace EventSurvey.Helper
{
    public class Mail
    {
        string FromMailId = ConfigurationManager.AppSettings["FromMailId"];
        string Password = ConfigurationManager.AppSettings["Password"];
        string SMTPPath = ConfigurationManager.AppSettings["SMTPPath"];
        string SMTPPort = ConfigurationManager.AppSettings["SMTPPort"];
        string HostUrl = ConfigurationManager.AppSettings["WebLink"];
        public string Subject { get; set; }
        public string Body { get; set; }
        public List<string> To { get; set; }
        internal string br = "<br/>";
        private void Mailing()
        {
            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient(SMTPPath);
            mail.From = new MailAddress(FromMailId);
            foreach (var item in To)
                mail.To.Add(item);
            mail.Subject = Subject;
            mail.Body = Body;
            SmtpServer.Port = Convert.ToInt32(SMTPPort);
            SmtpServer.Credentials = new System.Net.NetworkCredential(FromMailId, Password);
            SmtpServer.EnableSsl = true;
            SmtpServer.Send(mail);
        }
        public void SetValues(List<string> to, string subject, string body)
        {
            To = to;
            Subject = subject;
            Body = body;
        }
        public void SendMail()
        {
            new Task(() => Mailing()).Start();
        }

        public string GenerateURL(int surveyId, string surveyName)
        {
            Encryption encryption = new Encryption();
            var encStoreID = encryption.Encrypt(surveyId.ToString());
            StringBuilder content = new StringBuilder();
            content.Append("Hi Team");
            content.AppendLine();
            content.AppendLine();
            content.Append("We are taking an survey for " + surveyName);
            content.AppendLine();
            content.AppendLine();
            content.Append($"Please answer the questions from the link. {HostUrl}/user/userResponse?surveyId={encStoreID}");
            content.AppendLine();
            content.AppendLine();
            content.Append("Thanks");
            content.AppendLine();
            content.AppendLine("Event Survey");
            return content.ToString();
        }
    }
}